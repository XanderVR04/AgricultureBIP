#include <Arduino.h>
#include <Wire.h>
#include "SensirionI2CSen5x.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiCredentials.h>

#define WIFI_SSID "HotspotLars"
#define WIFI_PASSWORD "Pass2003"

String serverName = "https://api.derooverit.com/measurement";

bool isConnected = false, isSent = false;

// put function declarations here:
int myFunction(int, int);

SensirionI2CSen5x sen55;

float datapin = 34;
float moissens = 0;
int mapped = 0;
int soilhumidity = 0;

float massConcentrationPm1p0;
float massConcentrationPm2p5;
float massConcentrationPm4p0;
float massConcentrationPm10p0;
float ambientHumidity;
float ambientTemperature;
float vocIndex;
float noxIndex;

void setup() {
  // put your setup code here, to run once:
  int result = myFunction(2, 3);

  pinMode(LED_BUILTIN, INPUT);
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.begin(921600);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  
  Serial.print("Starting...");

   while (!Serial) {
    delay(100);
  }
  
  Wire.begin(21, 22); // SDA, SCL

  uint16_t error;
  char errorMessage[256];

  sen55.begin(Wire);

  error = sen55.deviceReset();
  if (error) {
    Serial.print("Error trying to execute deviceReset(): ");
    errorToString(error, errorMessage, 256);
    Serial.println(errorMessage);
  }

  error = sen55.startMeasurement();
  if (error) {
    Serial.print("Error trying to execute startMeasurement(): ");
    errorToString(error, errorMessage, 256);
    Serial.println(errorMessage);
  }
}

void loop() {
  // put your main code here, to run repeatedly:
  if (WiFi.status() == WL_CONNECTED && !isConnected)
  {
    Serial.println(".");
    Serial.println("Connected");
    digitalWrite(LED_BUILTIN, HIGH);
    isConnected = true;
  }
  else if (WiFi.status() != WL_CONNECTED) 
  {
    Serial.print(".");
    digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
    delay(1000);
    isConnected = false;
  } else if(WiFi.status()== WL_CONNECTED && !isSent){
    HTTPClient http;
    WiFiClient client;

    http.begin(client, serverName);
      
    // If you need Node-RED/server authentication, insert user and password below
    //http.setAuthorization("REPLACE_WITH_SERVER_USERNAME", "REPLACE_WITH_SERVER_PASSWORD");
    
    http.addHeader("Content-Type", "application/json");
    String strPost = "{\"location\":\"KRE001GR\",\"temperature\":\"";
    strPost += ambientTemperature;
    strPost += "\",\"humidity\":\"";
    strPost += ambientHumidity;
    strPost += "\",\"moisture\":\"";
    strPost += soilhumidity;
    strPost += "\",\"particle_size_1\":\"";
    strPost += massConcentrationPm1p0;
    strPost += "\",\"particle_size_2_5\":\"";
    strPost += massConcentrationPm2p5;
    strPost += "\",\"particle_size_4\":\"";
    strPost += massConcentrationPm4p0;
    strPost += "\",\"particle_size_10\":\"";
    strPost += massConcentrationPm10p0;
    strPost += "\",\"organic_compounds\":\"";
    strPost += vocIndex;
    strPost += "\",\"nitrogen\":\"";
    strPost += noxIndex;
    strPost += "\"}";
    Serial.print(strPost);
    Serial.print(" | HTTP Response code: ");
    int httpResponseCode = http.POST(strPost);
    Serial.println(httpResponseCode);
    http.end();
    delay(10000);
  }

  moissens = analogRead(datapin);
  mapped = map(moissens, 0, 4095, 0, 100);
  soilhumidity = ((mapped - 100) * -1);
  Serial.print("Soil moisture: ");
  Serial.print(soilhumidity);
  Serial.println("%");

  uint16_t error;
  char errorMessage[256];

  delay(1000);

  error = sen55.readMeasuredValues(
    massConcentrationPm1p0, massConcentrationPm2p5, massConcentrationPm4p0,
    massConcentrationPm10p0, ambientHumidity, ambientTemperature, vocIndex,
    noxIndex);

  if (error) {
    Serial.print("Error trying to read measured values: ");
    errorToString(error, errorMessage, 256);
    Serial.println(errorMessage);
  } else {
    Serial.print("Air particles upto 1µm: ");
    Serial.print(massConcentrationPm1p0);
    Serial.println(" µg/m³");

    Serial.print("Air particles upto 2.5µm: ");
    Serial.print(massConcentrationPm2p5);
    Serial.println(" µg/m³");

    Serial.print("Air particles upto 4µm: ");
    Serial.print(massConcentrationPm4p0);
    Serial.println(" µg/m³");

    Serial.print("Air particles upto 10µm: ");
    Serial.print(massConcentrationPm10p0);
    Serial.println(" µg/m³");

    Serial.print("Ambient Humidity: ");
    Serial.print(ambientHumidity);
    Serial.println(" %");

    Serial.print("Ambient Temperature: ");
    Serial.print(ambientTemperature);
    Serial.println(" °C");

    Serial.print("VOC Index: ");
    Serial.print(vocIndex);
    Serial.println(" µg/m³");

    Serial.print("NOx Index: ");
    Serial.print(noxIndex);
    Serial.println(" µg/m³");
  }
}

// put function definitions here:
int myFunction(int x, int y) {
  return x + y;
}